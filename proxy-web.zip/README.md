# Proxy Web Server

A simple Node.js-based proxy server.

## Setup

```bash
npm install
npm start
```

## Usage

Visit:  
`http://localhost:3000/proxy?url=https://example.com`